import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main extends JFrame {
    private HashMap<String, String> emojiMap;
    private int emojiCount;

    private static final int TAMANO_VENTANA_ANCHO = 400;
    private static final int TAMANO_VENTANA_ALTO = 300;
    private static final int TAMANO_AREA_TEXTO_FILAS = 3;
    private static final int TAMANO_AREA_TEXTO_COLUMNAS = 20;
    private static final int TAMANO_EMOJI = 40;
    private static final int TAMANO_TEXTO_DIALOGO = 30;

    public Main() {
        setTitle("Emoji Interface");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(TAMANO_VENTANA_ANCHO, TAMANO_VENTANA_ALTO);
        setLocationRelativeTo(null);

        inicializarEmojiMap();
        emojiCount = 0;

        JLabel titleLabelBottom = new JLabel("Trabajo Final");
        titleLabelBottom.setFont(new Font("Algerian", Font.BOLD, 18));
        titleLabelBottom.setForeground(Color.BLUE);
        titleLabelBottom.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabelBottom, BorderLayout.NORTH);

        ImageIcon logo = new ImageIcon("png/logo.png");
        Image image = logo.getImage();
        Image newImage = image.getScaledInstance(250, 150, Image.SCALE_SMOOTH);
        logo = new ImageIcon(newImage);
        JLabel logoLabel = new JLabel(logo);
        add(logoLabel, BorderLayout.SOUTH);

        JPanel panel = new JPanel(new GridBagLayout());

        JTextArea textoArea = new JTextArea(TAMANO_AREA_TEXTO_FILAS, TAMANO_AREA_TEXTO_COLUMNAS);
        panel.add(new JScrollPane(textoArea), createConstraints(0, 0, 2, 1));

        JButton mostrarButton = new JButton("Imprimir emoji y palabra/as");
        mostrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarTextoYEmojis(textoArea.getText());
            }
        });
        panel.add(mostrarButton, createConstraints(0, 1, 1, 1));

        add(panel);

        setVisible(true);
    }

    private GridBagConstraints createConstraints(int gridx, int gridy, int gridwidth, int gridheight) {
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = gridx;
        constraints.gridy = gridy;
        constraints.gridwidth = gridwidth;
        constraints.gridheight = gridheight;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.insets = new Insets(2, 2, 2, 2);
        return constraints;
    }

    private void inicializarEmojiMap() {
        emojiMap = new HashMap<>();
        emojiMap.put("love", "001-emoji.png");
        emojiMap.put("B)", "002-emoticonos.png");
        emojiMap.put(":)", "003-feliz.png");
        emojiMap.put(":o", "004-conmocionado.png");
        emojiMap.put(":D", "005-sonriente.png");
        emojiMap.put(":)", "006-feliz-1.png");
        emojiMap.put("pensar", "007-pensando.png");
        emojiMap.put("confundido", "008-confuso.png");
        emojiMap.put(":(", "009-triste.png");
        emojiMap.put("lol", "010-risa.png");
        emojiMap.put("enojado", "011-enojado.png");
        emojiMap.put("sorprendido", "012-conmocionado-1.png");
        emojiMap.put("preocupado", "013-preocuparse.png");
        emojiMap.put("8)", "014-sonrisa.png");
        emojiMap.put("lloron", "015-emoji-1.png");
        emojiMap.put("estrella", "016-estrella.png");
        emojiMap.put("gol", "017-partido.png");
        emojiMap.put("cochino", "018-guino.png");
        emojiMap.put("animado", "019-entusiasta.png");
        emojiMap.put("me gusta", "020-me-gusta.png");
        emojiMap.put("paul", "021-cabeza-alienigena.png");
        emojiMap.put("gatico", "022-gato.png");
        emojiMap.put("e.t", "023-cabeza-alienigena-1.png");
        emojiMap.put("zzz", "024-emoji-2.png");
        emojiMap.put("juanma", "025-nerd.png");
        emojiMap.put("heroe", "026-superhombre.png");
        emojiMap.put("cool", "027-fresco.png");
        emojiMap.put("malo", "028-pulgares-abajo.png");
        emojiMap.put("perro", "029-triste-1.png");
        emojiMap.put("payaso", "030-payaso.png");
    }

    private void mostrarTextoYEmojis(String texto) {
        JPanel emojiPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        int palabrasEnDiccionario = 0;
        emojiCount = 0;

        String[] palabras = texto.split("\\s+");

        for (String palabra : palabras) {
            String nombreArchivo = emojiMap.getOrDefault(palabra, null);
            if (nombreArchivo != null) {
                emojiCount++;
                ImageIcon icono = new ImageIcon("png/" + nombreArchivo);
                Image imagenEscalada = icono.getImage().getScaledInstance(TAMANO_EMOJI, TAMANO_EMOJI, Image.SCALE_SMOOTH);
                ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
                JLabel emojiLabel = new JLabel(iconoEscalado);
                emojiPanel.add(emojiLabel);
            } else {
                if (esPalabraEnDiccionario(palabra)) {
                    palabrasEnDiccionario++;
                }
                JLabel textoLabel = new JLabel(palabra + " ");
                textoLabel.setFont(new Font("Arial", Font.PLAIN, TAMANO_TEXTO_DIALOGO));
                emojiPanel.add(textoLabel);
            }
        }

        JPanel contadorPanel = new JPanel(new GridLayout(2, 1));
        contadorPanel.add(new JLabel("Palabras encontradas en el Diccionario: " + palabrasEnDiccionario));
        JLabel emojiCountLabel = new JLabel("Contador de Emojis: " + emojiCount);
        emojiCountLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
        contadorPanel.add(emojiCountLabel);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(emojiPanel, BorderLayout.CENTER);
        mainPanel.add(contadorPanel, BorderLayout.SOUTH);

        JOptionPane.showMessageDialog(this, mainPanel, "Texto, Emojis y Contadores", JOptionPane.PLAIN_MESSAGE);
    }

    private boolean esPalabraEnDiccionario(String palabra) {
        File diccionarioFile = new File("diccionario.txt");

        if (diccionarioFile.exists() && diccionarioFile.isFile()) {
            try (BufferedReader br = new BufferedReader(new FileReader(diccionarioFile))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    if (contienePalabraEnLinea(linea, palabra)) {
                        return true;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return false;
    }

    private boolean contienePalabraEnLinea(String linea, String palabra) {
        String regex = "\\b" + quitarDiacriticos(palabra) + "(\\S*)?\\b";

        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        Matcher matcher = pattern.matcher(quitarDiacriticos(linea));

        return matcher.find();
    }

    private String quitarDiacriticos(String input) {
        return java.text.Normalizer.normalize(input, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main();
            }
        });
    }
}
